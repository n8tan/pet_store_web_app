package factory;

import model.bird_kind.Bird;
import model.dog_kind.Dog;
import model.fish_kind.Fish;

public interface AbstractPetFactory {
	
	Bird getBird(String type);
	Dog getDog(String type);
	Fish getFish(String type);
	
}
