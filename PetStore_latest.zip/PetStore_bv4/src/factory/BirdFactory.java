package factory;

import model.bird_kind.Bird;
import model.bird_kind.Cockatoo;
import model.bird_kind.Macaw;
import model.bird_kind.Parrot;
import model.dog_kind.Dachshund;
import model.dog_kind.Dog;
import model.dog_kind.JapaneseSpitz;
import model.dog_kind.PitBull;
import model.fish_kind.Fish;

public class BirdFactory implements AbstractPetFactory {

	@Override
	public Bird getBird(String type) {
		Bird result = null;
		
		switch (type) {
		
			case "Parrot":
				result = new Parrot();
				break;
				
			case "Macaw":
				result = new Macaw();
				break;
			
			case "Cockatoo":
				result = new Cockatoo();
				break;
				
		}

		return result;
	}

	@Override
	public Dog getDog(String type) {
		return null;
	}

	@Override
	public Fish getFish(String type) {
		return null;
	}

}
