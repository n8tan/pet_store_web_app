package factory;

public class FactoryProducer {
	
	public static AbstractPetFactory getFactory(String choice) {
		
		AbstractPetFactory factory = null;
		switch (choice) {
			case "Dog":
				factory = new DogFactory();
				break;
	
			case "Bird":
				factory = new BirdFactory();
				break;
			case "Fish":
				factory = new FishFactory();
				break;
		}
		
		return factory;
	}
}
