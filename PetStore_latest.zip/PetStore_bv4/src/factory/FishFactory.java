package factory;

import model.bird_kind.Bird;
import model.dog_kind.Dachshund;
import model.dog_kind.Dog;
import model.dog_kind.JapaneseSpitz;
import model.dog_kind.PitBull;
import model.fish_kind.BlackMolly;
import model.fish_kind.Fish;
import model.fish_kind.Goldfish;
import model.fish_kind.Platies;

public class FishFactory implements AbstractPetFactory {

	@Override
	public Fish getFish(String type) {
		Fish result = null;
		
		switch (type) {
		
			case "Goldfish":
				result = new Goldfish();
				break;
				
			case "Platies":
				result = new Platies();
				break;
			
			case "Black Molly":
				result = new BlackMolly();
				break;
				
		}

		return result;
	}
	
	@Override
	public Bird getBird(String type) {
		return null;
	}

	@Override
	public Dog getDog(String type) {
		return null;
	}

	

}
