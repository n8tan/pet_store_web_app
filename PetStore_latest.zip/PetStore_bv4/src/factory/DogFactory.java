package factory;

import model.bird_kind.Bird;
import model.dog_kind.Dachshund;
import model.dog_kind.Dog;
import model.dog_kind.JapaneseSpitz;
import model.dog_kind.PitBull;
import model.fish_kind.Fish;

public class DogFactory implements AbstractPetFactory {

	@Override
	public Dog getDog(String type) {
		Dog result = null;
		
		switch (type) {
		
			case "Japanese Spitz":
				result = new JapaneseSpitz();
				break;
				
			case "Dachshund":
				result = new Dachshund();
				break;
			
			case "Pit bull":
				result = new PitBull();
				break;
				
		}

		return result;
	}
	
	@Override
	public Bird getBird(String type) {
		return null;
	}

	@Override
	public Fish getFish(String type) {
		return null;
	}

}
