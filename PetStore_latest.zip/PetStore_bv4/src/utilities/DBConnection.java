package utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	
	private static Connection connection;
	
	private DBConnection() {
		
	}
	
	private static Connection getConnectionInstance() {
		
		if(connection == null) {
			try{
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/petstore", "root", "");
			} catch (SQLException sqle){
				sqle.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
		return connection;

	}
	public static Connection getConnection() {
		
		return (connection == null)?getConnectionInstance():connection;
	}
}
