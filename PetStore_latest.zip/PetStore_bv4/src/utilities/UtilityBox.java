package utilities;

import model.CustomerPet;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;

import java.util.List;

public class UtilityBox {
	
	PDFMaker pdfMaker;
	CreditCardValidator creditCard;
	
	public UtilityBox() {
			pdfMaker = new PDFMaker();
			creditCard = new CreditCardValidator();
	}
	
	public Document prepAndCreatePDF(String inputCreditCardType, String inputFirstName, String inputLastName,
					String inputMasked, List<CustomerPet> inputList, Document document) throws DocumentException {
		pdfMaker.prepare(inputCreditCardType, inputFirstName, inputLastName, inputMasked, inputList, document);
		return pdfMaker.createPDF();
	}
	
	public boolean checkCard(String cardNumber) {
		return creditCard.validateCreditCard(cardNumber);
	}
	
	public String identifyCard(String creditCardNumber) {
		return creditCard.identifyCreditCard(creditCardNumber);
	}
	
	public String maskCard(String creditCardNumber){
		return creditCard.maskCreditCard(creditCardNumber);
	}
	
}	
