package utilities;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;

import model.CustomerPet;
public class PDFMaker {
	
	private Document document;
	private String creditCardType;
	private String customerFirstName;
	private String customerLastName;
	private String maskedCard;
	private List<CustomerPet> orderList;
	
	private DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	private Date date = new Date();
	
	public PDFMaker() {
		
	}
	
	public PDFMaker(String inputCreditCardType, String inputFirstName,
				String inputLastName, String inputMasked, List<CustomerPet> inputList, Document document) {
		this.creditCardType = inputCreditCardType;
		this.customerFirstName = inputFirstName;
		this.customerLastName = inputLastName;
		this.maskedCard = inputMasked;
		this.orderList = inputList;
		this.document = document;
	}
	
	public void prepare(String inputCreditCardType, String inputFirstName, String inputLastName, String inputMasked,
							List<CustomerPet> inputList, Document document) {
		this.creditCardType = inputCreditCardType;
		this.customerFirstName = inputFirstName;
		this.customerLastName = inputLastName;
		this.maskedCard = inputMasked;
		this.orderList = inputList;
		this.document = document;
	}
	
	public Document createPDF() throws DocumentException {
		
		document.open();
		Paragraph para = new Paragraph();
		para.add(new Phrase("Chris's Pet Store" + "\n"));
		para.add(new Phrase("Date/Time: " + dateFormat.format(date)+"\n\n"));
		para.add(new Phrase("Card:" + creditCardType + "\n"));
		para.add(new Phrase(maskedCard + "\n\n"));
		para.add(new Phrase("------------------------------\n"));
		para.add(new Phrase("SALE" + "\n"));
		//para.add(new Phrase("Pet------------------------Price" + "\n"));
		int total = 0;
		for (CustomerPet pet : orderList) {
			para.add(new Phrase(pet.getPetBreed() + "-Php "+ pet.getPetPrice() + "\n"));
			total+=pet.getPetPrice();
		}
		para.add(new Phrase("------------------------------\n"));
		para.add(new Phrase("Total: Php " + total + "\n\n\n"));
		para.add(new Phrase("Customer Name: " + customerFirstName + " " + customerLastName + "\n"));
		para.add(new Phrase("Sign X____________________________\n"));
		para.add(new Phrase("I agree to pay above total amount\n"));
		para.add(new Phrase("according to card issuer agreement.\n"));
		para.add(new Phrase("---CUSTOMER COPY---"));
		para.setAlignment(Paragraph.ALIGN_CENTER);
		document.add(para);
		document.close();
		
		return document;
		
	}
}
