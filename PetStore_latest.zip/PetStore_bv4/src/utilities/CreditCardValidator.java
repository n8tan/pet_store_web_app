package utilities;

public class CreditCardValidator {
	
	public CreditCardValidator() {
		
	}
	
	public boolean validateCreditCard(String cardNumber) {
    	//Place here the credit card verification process. This uses the string value inputed.
    	char[] cardInput = cardNumber.toCharArray();
    	int inputLength = cardInput.length;
    	int lastIndex = (inputLength - 1);
    	int luhnStartingIndex = (lastIndex - 1);
    	int[] creditCardNumber = new int[inputLength];
    	int sum = 0;
    	
    	if(inputLength < 13) {
    		return false;
    	}else if(inputLength > 19) {
    		return false;
    	}
    	
    	for(int counter = 0; counter <= lastIndex; counter++) {
    		creditCardNumber[counter] = Character.getNumericValue(cardInput[counter]);
    	}
    	
    	for(int num = luhnStartingIndex; num >= 0; num = num-2) {
    		creditCardNumber[num] = (creditCardNumber[num] * 2);
    		if(creditCardNumber[num] > 9) {
    			int comparison = 0;
    			comparison = creditCardNumber[num];
    			switch (comparison) {
				case (10): creditCardNumber[num] = 1;
					break;
				case (12): creditCardNumber[num] = 3;
					break;
				case (14): creditCardNumber[num] = 5;
					break;
				case (16): creditCardNumber[num] = 7;
					break;
				case (18): creditCardNumber[num] = 9;
					break;
				default:
					break;
				}
    		}
    	}
    	
    	for(int counter = 0; counter <= lastIndex; counter++) {
    		sum = sum + creditCardNumber[counter];
    	}
    	
    	if(sum%10 == 0) {
    		return true; //valid
    	} else {
    		return false; //invalid
    	}
    	
	}
	
	public String identifyCreditCard(String creditCardNumber) {
			
			char[] inputCreditCard = creditCardNumber.toCharArray();
			int inputLength = inputCreditCard.length;
			String creditCardType = "OTHER CREDIT CARD TYPE";
			if(inputLength == 13) {
				if(inputCreditCard[0] == '4') {
					creditCardType = "VISA";
				}
			}else if(inputLength == 14) {
				if(inputCreditCard[0] == '3') {
					if(inputCreditCard[1] == '0' || inputCreditCard[1] == '6' || inputCreditCard[1] == '8') {
						creditCardType = "DINERS CLUB";
					}
				}
			}else if(inputLength == 15) {
				if(inputCreditCard[0] == '3') {
					if(inputCreditCard[1] == '4' || inputCreditCard[1] == '7') {
						creditCardType = "AMERICAN EXPRESS";
					}
				} else if(inputCreditCard[0] == '2' && inputCreditCard[1] == '0' && inputCreditCard[2] == '1' && inputCreditCard[3] == '4') {
					creditCardType = "EN ROUTE";
				} else if(inputCreditCard[0] == '2' && inputCreditCard[1] == '1' && inputCreditCard[2] == '4' && inputCreditCard[3] == '9') {
					creditCardType = "EN ROUTE";
				}
			}else if(inputLength == 16) {
				if(inputCreditCard[0] == '5') {
					if(inputCreditCard[1] == '1' || inputCreditCard[1] == '2' || inputCreditCard[1] == '3' || inputCreditCard[1] == '4' || 
							inputCreditCard[1] == '5') {
						creditCardType = "MASTERCARD";
					}
				} else if(inputCreditCard[0] == '4') {
					creditCardType = "VISA";
				}
			}
			return creditCardType;
		}
	
	public String maskCreditCard (String creditCardNumber) {
		
		char[] inputCard = creditCardNumber.toCharArray();
		int cardLength = inputCard.length;
		String maskedCard = "";
		for(int counter = 0; counter < cardLength; counter++) {
			if(counter < 12) {
				inputCard[counter] = 'X';
			}
		}
		
		for(int counter = 0; counter < cardLength; counter++) {
			if(counter == 4 || counter == 8 || counter == 12) {
				maskedCard = maskedCard + ' ' + inputCard[counter];
			} else {
				maskedCard = maskedCard + inputCard[counter];
			}
			
		}
		return maskedCard;
	}
}
