package controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.CustomerPet;
import utilities.DBConnection;

/**
 * Servlet implementation class CheckOutServlet
 */
@WebServlet("/CheckOutServlet")
public class CheckOutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
		List<CustomerPet> ordersList;
		PurchasePet purchasePet = new PurchasePet();
		purchasePet.setOrdersList(new ArrayList<CustomerPet>());
		
		if(session.getAttribute("orders") != null) {
			purchasePet = (PurchasePet) session.getAttribute("orders");
		}
		
		if(!purchasePet.getOrdersList().isEmpty()) {
			System.out.println("Storing ordersList object into session");
			session.setAttribute("orders", purchasePet);
			
			System.out.println("Now forwarding to show_cart.jsp");
			request.getRequestDispatcher("checkout.jsp").forward(request,response);

		}else {
			request.getRequestDispatcher("error_empty.jsp").forward(request, response);
		}
	}

}
