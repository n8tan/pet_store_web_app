package controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.CustomerPet;
import model.Customer_Pet_Builder;
import model.Customer_Pet_Director;
import model.Pet_Builder;
import factory.AbstractPetFactory;
import factory.FactoryProducer;
import utilities.CreditCardValidator;
import utilities.DBConnection;
public class ProcessServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	@SuppressWarnings("unchecked")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
		//List<CustomerPet> ordersList;
		
		String submitBtn = request.getParameter("submit");
		PurchasePet purchasePet = null;
		
		if(session.getAttribute("orders") != null) {
			purchasePet = (PurchasePet) session.getAttribute("orders");
		}
				
		Connection connection = DBConnection.getConnection();
		if(connection == null) {
			response.sendRedirect("error_db.jsp");
			return;
		}
		
		if(submitBtn.equals("add")) {
			String inputPetName = request.getParameter("petName");
			String inputPetKind = request.getParameter("petKind");
			
			if(inputPetName.trim().equals("")){
				request.getRequestDispatcher("error_input.jsp").forward(request, response);
				/*response.sendRedirect("error_input.jsp");
				return;*/	
			}else {
				//Shorten this code using builder pattern
				//Letting the builder use the factories to build the CustomerPet object
				CustomerPet customer = null;
				
				if(purchasePet == null) {
					purchasePet = new PurchasePet(inputPetName,inputPetKind,request);
					purchasePet.setOrdersList(new ArrayList<CustomerPet>());
				}else {
					purchasePet.preparePet(inputPetName, inputPetKind, request);
				}
				
				customer = purchasePet.retrievePet();
				purchasePet.addOrder(customer);

				
				
				System.out.println("Storing ordersList object into session");
				session.setAttribute("orders", purchasePet);
				
				System.out.println("Storing customer into request.");
				request.setAttribute("customerPet", customer);
				
				System.out.println("Now forwarding to displayoutput.jsp");
				request.getRequestDispatcher("displayoutput.jsp").forward(request, response);
			}
			
			
		}else if(submitBtn.equals("finish")){
			System.out.println("Session finished.");
			session.invalidate();
			response.sendRedirect("index.jsp");
			return;
			
		}else if(submitBtn.equals("clear")) {
			System.out.println("Clearing contents.");
			purchasePet.getOrdersList().clear();
			session.setAttribute("orders", purchasePet);
			System.out.println("Now forwarding to show_cart.jsp");
			request.getRequestDispatcher("show_cart.jsp").forward(request, response);
		}
		
	
	}

}
