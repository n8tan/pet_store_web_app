package controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.CustomerPet;
import model.PetOrdersIterator;
import utilities.CreditCardValidator;
import utilities.DBConnection;
import utilities.UtilityBox;

/**
 * Servlet implementation class PurchaseServlet
 */
@WebServlet("/PurchaseServlet")
public class PurchaseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		HttpSession session = request.getSession(true);
		List<CustomerPet> ordersList;
		UtilityBox tools = new UtilityBox();
		PurchasePet purchasePet = null;
		
		if(session.getAttribute("orders") != null) {
			purchasePet = (PurchasePet) session.getAttribute("orders");
		}
				
		Connection connection = DBConnection.getConnection();
		if(connection == null) {
			response.sendRedirect("error_db.jsp");
			return;
		}
		
		String creditCardNumber = request.getParameter("creditCard");
		
		
		if(tools.checkCard(creditCardNumber)) {
			System.out.println("Valid credit card.");
			
			String customerFirstName = request.getParameter("firstName");
			String customerLastName = request.getParameter("lastName");
			if(!customerFirstName.trim().equals("") && !customerLastName.trim().equals("")){
				//Saving each pet after purchase.
				Iterator<CustomerPet> ordersIterator = purchasePet.createIterator();
				while(ordersIterator.hasNext()) {
					CustomerPet pet = ordersIterator.next();
					pet.save(connection);
				}
				
	//			for (CustomerPet pet : purchasePet.getOrdersList()) {
	//				pet.save(connection);
	//			}
				
				
				String creditCardType = tools.identifyCard(creditCardNumber);
				String maskedCard = tools.maskCard(creditCardNumber);
				
				session.setAttribute("customerFirstName", customerFirstName);
				session.setAttribute("customerLastName", customerLastName);
				session.setAttribute("creditCardType", creditCardType);
				session.setAttribute("maskedCard", maskedCard);
				
				request.getRequestDispatcher("receipt.jsp").forward(request, response);
			}else {
				request.getRequestDispatcher("error_input.jsp").forward(request, response);

			}
		}else {
			request.getRequestDispatcher("error_credit_card.jsp").forward(request, response);
		}
	}

}
