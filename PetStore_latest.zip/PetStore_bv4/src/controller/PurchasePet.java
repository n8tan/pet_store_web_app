package controller;

import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import model.CustomerPet;
import model.Customer_Pet_Builder;
import model.Customer_Pet_Director;
import model.PetOrdersIterator;
import model.Pet_Builder;

public class PurchasePet implements PetOrdersIterator {
	
	private String petName;
	private String petKind;
	private HttpServletRequest request;
	private List<CustomerPet> ordersList;
	
	public PurchasePet() {
		
	}
	
	public PurchasePet(String inputName, String inputKind, HttpServletRequest request) {
		this.petName = inputName;
		this.petKind = inputKind;
		this.request = request;
	}
	
	public void preparePet(String inputName, String inputKind, HttpServletRequest request) {
		this.petName = inputName;
		this.petKind = inputKind;
		this.request = request;
	}
	
	public List<CustomerPet> getOrdersList() {
		return this.ordersList;
	}
	
	public void setOrdersList(List<CustomerPet> ordersList) {
		this.ordersList = ordersList;
	}
	
	public void addOrder(CustomerPet pet) {
		this.ordersList.add(pet);
	}
	
	public CustomerPet retrievePet() {
		CustomerPet customer = null;
		
		Pet_Builder cp_builder = new Customer_Pet_Builder();
		Customer_Pet_Director cp_director = new Customer_Pet_Director(cp_builder);
		
		cp_director
			.constructPetName(petName)
			.constructPetKind(petKind);
		
		if(petKind.equals("Dog")) {
				cp_director
					.constructPetBreed(request.getParameter("dogBreed"))
					.constructPetPrice(request.getParameter("dogBreed"));
					
		}else if(petKind.equals("Bird")) {
				cp_director
					.constructPetBreed(request.getParameter("birdBreed"))
					.constructPetPrice(request.getParameter("birdBreed"));
				
		}else if(petKind.equals("Fish")) {
				cp_director
					.constructPetBreed(request.getParameter("fishBreed"))
					.constructPetPrice(request.getParameter("fishBreed"));
		}
		customer = cp_director
						.constructPetOrder()
						.getCustomerPet();

		//Log Stuff
		System.out.println(customer.getPetName());
		System.out.println(customer.getPetKind());
		System.out.println(customer.getPetBreed());
		
		return customer;
	}

	@Override
	public Iterator createIterator() {
		return this.getOrdersList().iterator();
	}
}
