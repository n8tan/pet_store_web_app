package controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import utilities.PDFMaker;
import utilities.UtilityBox;
import model.CustomerPet;

import com.itextpdf.text.Document;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfWriter;

/**
 * Servlet implementation class PrintReceiptServlet
 */
@WebServlet("/PrintReceiptServlet")
public class PrintReceiptServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("application/pdf");
		
		HttpSession session = request.getSession(true);
		UtilityBox tools = new UtilityBox();
		PurchasePet purchasePet = null;
		
		String creditCardType = (String) session.getAttribute("creditCardType");
		String customerFirstName = (String) session.getAttribute("customerFirstName");
		String customerLastName = (String) session.getAttribute("customerLastName");
		String maskedCard = (String) session.getAttribute("maskedCard");
		purchasePet = (PurchasePet) session.getAttribute("orders");
		
		Document document = new Document();
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		
		try{
			PdfWriter.getInstance(document, 
				response.getOutputStream());
			
			document = tools.prepAndCreatePDF(creditCardType, customerFirstName,
						customerLastName, maskedCard, purchasePet.getOrdersList(), document);		
			
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch(Exception e){
            e.printStackTrace();
        }
		
		
		
	}

}

























/*document.open();
Paragraph para = new Paragraph();
para.add(new Phrase("Chris's Pet Store" + "\n"));
para.add(new Phrase("Date/Time: " + dateFormat.format(date)+"\n\n"));
para.add(new Phrase("Card:" + creditCardType + "\n"));
para.add(new Phrase(maskedCard + "\n\n"));
para.add(new Phrase("------------------------------\n"));
para.add(new Phrase("SALE" + "\n"));
//para.add(new Phrase("Pet------------------------Price" + "\n"));
int total = 0;
for (CustomerPet pet : orderList) {
	para.add(new Phrase(pet.getPetBreed() + "-Php "+ pet.getPetPrice() + "\n"));
	total+=pet.getPetPrice();
}
para.add(new Phrase("------------------------------\n"));
para.add(new Phrase("Total: Php " + total + "\n\n\n"));
para.add(new Phrase("Customer Name: " + customerFirstName + " " + customerLastName + "\n"));
para.add(new Phrase("Sign X____________________________\n"));
para.add(new Phrase("I agree to pay above total amount\n"));
para.add(new Phrase("according to card issuer agreement.\n"));
para.add(new Phrase("---CUSTOMER COPY---"));
para.setAlignment(Paragraph.ALIGN_CENTER);
document.add(para);
document.close();*/