package model;

import factory.FactoryProducer;

public class Customer_Pet_Builder implements Pet_Builder{
	
	private CustomerPet customer;
	
	public Customer_Pet_Builder() {
		customer = new CustomerPet();
	}
	
	@Override
	public void buildPetName(String inputName) {
		customer.setPetName(inputName);
	}

	@Override
	public void buildPetBreed(String inputBreed) {
		customer.setPetBreed(inputBreed);		
	}

	@Override
	public void buildPetKind(String inputKind) {
		customer.setPetKind(inputKind);
	}

	@Override
	public void buildPetOrder() {
			switch (customer.getPetKind()) {
				case "dog":
					customer.setPetDog(FactoryProducer.getFactory(customer.getPetKind())
							.getDog(customer.getPetBreed()));
					
					break;
		
				case "bird":
					customer.setPetBird(FactoryProducer.getFactory(customer.getPetKind())
							.getBird(customer.getPetBreed()));
					break;
				
				case "fish":
					customer.setPetFish(FactoryProducer.getFactory(customer.getPetKind())
							.getFish(customer.getPetBreed()));
					break;
			
			}
	}
	
	@Override
	public void buildPetPrice(String inputBreed) {
		
		switch (inputBreed) {
			case "Japanese Spitz":
				customer.setPetPrice(8000);
			break;
			
			case "Dachshund":
				customer.setPetPrice(3500);
			break;
			
			case "Pit bull":
				customer.setPetPrice(3500);
			break;
			
			case "Parrot":
				customer.setPetPrice(8000);
			break;
			
			case "Macaw":
				customer.setPetPrice(8000);
			break;
			
			case "Cockatoo":
				customer.setPetPrice(8000);
			break;
			
			case "Goldfish":
				customer.setPetPrice(35);
			break;
			
			case "Platies":
				customer.setPetPrice(25);
			break;
			
			case "Black Molly":
				customer.setPetPrice(25);
			break;

		} 
		
	}
	
	@Override
	public CustomerPet getPet() {
		
		return customer;
	}

	
	
}
