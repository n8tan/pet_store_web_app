package model.dog_kind;

public class Dachshund implements Dog {
	
	private String name;
	
	@Override
	public String bark() {
		return "Dachshund can bark!";

	}

	@Override
	public String run() {
		return "Dachshund can run!";

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
