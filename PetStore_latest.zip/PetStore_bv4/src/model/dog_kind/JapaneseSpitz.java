package model.dog_kind;

public class JapaneseSpitz implements Dog {
	
	private String name;
	@Override
	public String bark() {
		return "Japanse Spitz can bark!";

	}

	@Override
	public String run() {
		return "Japanese Spitz can run!";

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
