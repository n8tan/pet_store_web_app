package model.dog_kind;

public class PitBull implements Dog {

	private String name;
	
	@Override
	public String bark() {
		return "Pitbull can bark!";

	}

	@Override
	public String run() {
		return "Pitbull can run!";

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
