package model.dog_kind;

public interface Dog {
	
	String bark();
	String run();
}
