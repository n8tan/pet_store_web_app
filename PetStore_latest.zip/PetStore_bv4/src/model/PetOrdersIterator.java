package model;

import java.util.Iterator;

public interface PetOrdersIterator {
	public Iterator createIterator();
}	
