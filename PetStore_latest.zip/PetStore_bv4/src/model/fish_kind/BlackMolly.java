package model.fish_kind;


public class BlackMolly implements Fish {
	
	private String name;
	@Override
	public String swim() {
		return "Black Molly can swim!";
	}

	@Override
	public String hide() {
		return "Black Molly can hide!";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
