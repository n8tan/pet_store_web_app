package model.fish_kind;


public class Platies implements Fish {
	
	private String name;
	
	@Override
	public String swim() {
		return "Platies can swim!";

	}

	@Override
	public String hide() {
		return "Platies can hide!";

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
