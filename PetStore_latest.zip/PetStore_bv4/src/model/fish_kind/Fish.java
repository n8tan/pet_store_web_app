package model.fish_kind;

public interface Fish {
	
	String swim();
	String hide();
}
