package model.fish_kind;


public class Goldfish implements Fish {
	
	private String name;
	
	@Override
	public String swim() {
		return "Goldfish can swim!";

	}

	@Override
	public String hide() {
		return "Goldfish can hide!";

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
