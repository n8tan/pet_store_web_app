package model.bird_kind;


public class Parrot implements Bird {
	
	private String name;
	@Override
	public String fly() {
		return "Parrot can fly!";

	}

	@Override
	public String chirp() {
		return "Parrot can chirp!";

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
