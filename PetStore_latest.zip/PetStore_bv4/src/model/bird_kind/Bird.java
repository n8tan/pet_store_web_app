package model.bird_kind;

public interface Bird {
	
	String fly();
	String chirp();
}
