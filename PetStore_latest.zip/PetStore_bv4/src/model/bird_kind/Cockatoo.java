package model.bird_kind;


public class Cockatoo implements Bird {

	private String name;
	@Override
	public String fly() {
		return "Cockatoo can fly!";

	}

	@Override
	public String chirp() {
		return "Cockatoo can chirp!";

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
