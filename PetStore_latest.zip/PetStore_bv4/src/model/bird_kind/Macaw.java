package model.bird_kind;


public class Macaw implements Bird {
	
	private String name;
	
	@Override
	public String fly() {
		return "Macaw can fly!";

	}

	@Override
	public String chirp() {
		return "Macaw can chirp!";

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
