package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import model.bird_kind.Bird;
import model.dog_kind.Dog;
import model.fish_kind.Fish;
import factory.FactoryProducer;

public class CustomerPet {
	private String petName;
	private String petBreed;
	private String petKind;
	private int petPrice;
	
	private Dog petDog;
	private Fish petFish;
	private Bird petBird;
	
	CustomerPet() {
		
	}
/*	
	private CustomerPet(CustomerPetBuilder cpb) {
		
			this.petName = cpb.petName;
			this.petBreed = cpb.petBreed;
			this.petKind = cpb.petKind;

	}*/
	
	public String save(Connection connection) {
		System.out.println("Inside save method");
		String sqlStatement = "insert into " 
				+ "pets(petName, petKind, " 
				+ "petBreed) "
				+ "values (?,?,?)";
		
		try {
			PreparedStatement prep = 
				connection.prepareStatement(sqlStatement);
			
			prep.setString(1, petName);
			System.out.println("Pet Name inserted");
			prep.setString(2, petKind);
			System.out.println("Pet Kind Inserted");
			prep.setString(3, petBreed);
			System.out.println("Pet Breed Inserted");
			
			prep.executeUpdate();
			System.out.println("Now Returning");
			return "Save Successful!";
		}catch (SQLException sqle) {
			sqle.printStackTrace();
			return "Error in saving!";
		} catch (Exception e) {
			e.printStackTrace();
			return "Something went wrong!";
		}
				
	}
	
	/*public static class CustomerPetBuilder {
		public String petName;
		public String petBreed;
		public String petKind;

		public Dog petDog;
		public Fish petFish;
		public Bird petBird;
		
		public CustomerPetBuilder petName(String inputName) {
			this.petName = inputName;
			return this;
		}
		
		public CustomerPetBuilder petBreed(String inputBreed) {
			this.petBreed = inputBreed;
			return this;
		}
		
		public CustomerPetBuilder petKind(String inputKind) {
			this.petKind = inputKind;
			return this;
		}
		
		public CustomerPetBuilder orderPet() {
			switch (this.petKind) {
				case "dog":
					this.petDog = FactoryProducer
						.getFactory(this.petKind)
						.getDog(this.petBreed);
					break;
	
				case "bird":
					this.petBird = FactoryProducer
						.getFactory(this.petKind)
						.getBird(this.petBreed);
					break;
				
				case "fish":
					this.petFish = FactoryProducer
						.getFactory(this.petKind)
						.getFish(this.petBreed);
					break;
			}
			
			return this;
		}
		public CustomerPet build() {
			return new CustomerPet(this);
		}
		
	}*/
	
	public String getPetName() {
		return petName;
	}
	
	public String getPetBreed() {
		return petBreed;
	}
	public String getPetKind() {
		return petKind;
	}

	public int getPetPrice() {
		return petPrice;
	}
	public Dog getPetDog() {
		return petDog;
	}
	
	public Fish getPetFish() {
		return petFish;
	}

	public Bird getPetBird() {
		return petBird;
	}
	
	public void setPetName(String petName) {
		this.petName = petName;
	}

	public void setPetBreed(String petBreed) {
		this.petBreed = petBreed;
	}

	public void setPetKind(String petKind) {
		this.petKind = petKind;
	}

	public void setPetDog(Dog petDog) {
		this.petDog = petDog;
	}

	public void setPetFish(Fish petFish) {
		this.petFish = petFish;
	}

	public void setPetBird(Bird petBird) {
		this.petBird = petBird;
	}
	
	public void setPetPrice(int petPrice) {
		this.petPrice = petPrice;
	}
	
}
