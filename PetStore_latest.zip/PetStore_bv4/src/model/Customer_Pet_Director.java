package model;

public class Customer_Pet_Director {
	private Pet_Builder cp_builder = null;
	
	public Customer_Pet_Director(Pet_Builder builder) {
		this.cp_builder = builder;
	}
	
	public Customer_Pet_Director constructPetName(String inputName) {
		cp_builder.buildPetName(inputName);
		return this;
	}
	
	public Customer_Pet_Director constructPetKind(String inputKind) {
		cp_builder.buildPetKind(inputKind);
		return this;
	}
	
	public Customer_Pet_Director constructPetBreed(String inputBreed) {
		cp_builder.buildPetBreed(inputBreed);
		return this;
	}
	
	public Customer_Pet_Director constructPetOrder() {
		cp_builder.buildPetOrder();
		return this;
	}
	
	public Customer_Pet_Director constructPetPrice(String inputBreed) {
		cp_builder.buildPetPrice(inputBreed);
		return this;
	}
	public CustomerPet getCustomerPet() {
		return cp_builder.getPet();
	}
}
