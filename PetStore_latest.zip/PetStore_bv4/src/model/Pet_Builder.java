package model;

public interface Pet_Builder {
	
	public void buildPetName(String inputName);
	public void buildPetBreed(String inputBreed);
	public void buildPetKind(String inputKind);
	public void buildPetOrder();
	public void buildPetPrice(String inputBreed);
	public CustomerPet getPet();
	
}
