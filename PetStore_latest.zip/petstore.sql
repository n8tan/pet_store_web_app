-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2017 at 06:42 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `petstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `pets`
--

CREATE TABLE `pets` (
  `id` int(11) NOT NULL,
  `petName` varchar(50) NOT NULL,
  `petKind` varchar(50) NOT NULL,
  `petBreed` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pets`
--

INSERT INTO `pets` (`id`, `petName`, `petKind`, `petBreed`) VALUES
(1, 'Wimpy', 'dog', 'dachshund'),
(2, 'FIshy-Fishy', 'fish', 'goldfish'),
(3, 'Tweety-Bird', 'bird', 'macaw'),
(4, 'Loafy', 'dog', 'pitbull'),
(5, 'Cogsworth', 'dog', 'japanesespitz'),
(6, 'Pet1', 'dog', 'Japanese Spitz'),
(7, 'Dog2', 'dog', 'Dachshund'),
(8, 'Pet3', 'dog', 'Pit Bull'),
(9, 'Pet4', 'bird', 'Parrot'),
(10, 'Pet5', 'bird', 'Macaw'),
(11, 'Pet6', 'bird', 'Cockatoo'),
(12, 'Pet7', 'fish', 'Goldfish'),
(13, 'Pet8', 'fish', 'Platies'),
(14, 'Pet9', 'fish', 'Black Molly'),
(15, 'Pet1', 'dog', 'japanesespitz'),
(16, 'Pet2', 'dog', 'dachshund'),
(17, 'Pet3', 'dog', 'pitbull'),
(18, 'Pet4', 'bird', 'parrot'),
(19, 'Pet5', 'bird', 'macaw'),
(20, 'Pet6', 'bird', 'cockatoo'),
(21, 'Pet7', 'fish', 'goldfish'),
(22, 'Pet8', 'fish', 'platies'),
(23, 'Pet9', 'fish', 'blackmolly'),
(24, 'Pet1', 'dog', 'dachshund'),
(25, 'Pet2', 'bird', 'macaw'),
(26, 'Pet3', 'fish', 'blackmolly'),
(27, 'Wimpy', 'dog', 'japanesespitz'),
(28, 'Germany', 'bird', 'japanesespitz'),
(29, 'Germany', 'bird', 'japanesespitz'),
(30, 'Germany', 'bird', 'cockatoo'),
(31, 'Philippines', 'fish', 'blackmolly'),
(32, 'Poland', 'dog', 'dachshund'),
(33, 'Philippines', 'bird', 'macaw'),
(34, 'America', 'fish', 'platies'),
(35, 'China', 'dog', 'pitbull'),
(36, 'Pet-1', 'Dog', 'Japanese Spitz'),
(37, 'Pet-2', 'Dog', 'Dachshund'),
(38, 'Pet-3', 'Dog', 'Pit bull'),
(39, 'Pet-4', 'Bird', 'Parrot'),
(40, 'Pet-5', 'Bird', 'Macaw'),
(41, 'Pet-6', 'Bird', 'Cockatoo'),
(42, 'Pet-7', 'Fish', 'Goldfish'),
(43, 'Pet-8', 'Fish', 'Platies'),
(44, 'Pet-9', 'Fish', 'Black Molly'),
(45, 'Wimpy', 'Dog', 'Dachshund'),
(46, 'Fishy-fishy', 'Fish', 'Black Molly'),
(47, 'Boris teh slav dog xd', 'Dog', 'Japanese Spitz'),
(48, 'Boris teh slav dog xD', 'Dog', 'Pit bull'),
(49, 'Wimpy', 'Dog', 'Dachshund'),
(50, 'Wimpy', 'Dog', 'Dachshund'),
(51, 'Wimpy', 'Dog', 'Japanese Spitz'),
(52, 'Wimpy', 'Dog', 'Dachshund'),
(53, 'Wimpy', 'Dog', 'Japanese Spitz'),
(54, 'Wimpy', 'Dog', 'Dachshund'),
(55, 'Wimpy', 'Dog', 'Dachshund'),
(56, 'Wimpy', 'Dog', 'Dachshund'),
(57, 'Wimpy', 'Dog', 'Dachshund'),
(58, 'Wimpy', 'Dog', 'Dachshund'),
(59, 'cyka blyat drink vodka uuuhhhhhhh.....', 'Dog', 'Pit bull'),
(60, 'Pet_1', 'Dog', 'Japanese Spitz'),
(61, 'Pet_2', 'Dog', 'Dachshund'),
(62, 'Pet_3', 'Dog', 'Pit bull'),
(63, 'Pet_4', 'Bird', 'Parrot'),
(64, 'Pet_5', 'Bird', 'Macaw'),
(65, 'Pet_6', 'Bird', 'Cockatoo'),
(66, 'Pet_7', 'Fish', 'Goldfish'),
(67, 'Pet_8', 'Fish', 'Platies'),
(68, 'Pet_9', 'Fish', 'Black Molly'),
(69, 'Wimpy', 'Dog', 'Dachshund'),
(70, 'Tweety Bird', 'Bird', 'Macaw'),
(71, 'Fishy-Fishy', 'Fish', 'Goldfish'),
(72, 'Wimpy', 'Dog', 'Dachshund'),
(73, 'Beta', 'Bird', 'Parrot'),
(74, 'Charlie', 'Fish', 'Goldfish'),
(75, 'Wimpy', 'Dog', 'Dachshund'),
(76, 'Beta', 'Bird', 'Parrot'),
(77, 'Charlie', 'Fish', 'Goldfish'),
(78, 'Wimpy', 'Dog', 'Dachshund'),
(79, 'Beta-1', 'Bird', 'Macaw'),
(80, 'Charlie-2', 'Fish', 'Goldfish'),
(81, 'Wimpy~', 'Dog', 'Dachshund'),
(82, 'Beta-1', 'Bird', 'Macaw'),
(83, 'Charlie-2', 'Fish', 'Black Molly'),
(84, 'Wimpy!', 'Dog', 'Dachshund'),
(85, 'Beta-1', 'Bird', 'Cockatoo'),
(86, 'Charlie-2', 'Fish', 'Platies'),
(87, 'Wimpy#', 'Dog', 'Dachshund'),
(88, 'beta-1', 'Bird', 'Macaw'),
(89, 'charlie-2', 'Fish', 'Platies'),
(90, 'pandak', 'Dog', 'Dachshund'),
(91, 'Wimpy, my dog', 'Dog', 'Dachshund'),
(92, 'Wimpy', 'Dog', 'Japanese Spitz'),
(93, 'Wimpy', 'Dog', 'Dachshund'),
(94, 'Sample_bird', 'Bird', 'Parrot'),
(95, 'Sample_fish', 'Fish', 'Platies');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pets`
--
ALTER TABLE `pets`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pets`
--
ALTER TABLE `pets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
